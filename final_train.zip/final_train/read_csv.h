#ifndef READ_CSV_H
#define READ_CSV_H

#include <string>
#include <sstream>
#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

            // array of values for one line only

   vector< vector<string> > read_csv(string );

#endif