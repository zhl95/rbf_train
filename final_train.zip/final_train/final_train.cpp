// #include "opencl_pre.h";
// #include "initialize.h";

#define _CRT_SECURE_NO_WARNINGS
#define PROGRAM_FILE "distance.cl"

#define ARRAY_SIZE 4096
#define KERNEL_1 "reduction_vector"
#define KERNEL_2 "reduction_complete"
#define MANHATTAN_DIS_KERNEL "manhattan_distance"
#define MIN_DISTANCE_KERNEL "min_distance_reduction"
#define UPFATE_WEIGHT_KERNEL "update_weight"


#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
// #include <string>
#include <sstream>
#include <iostream>
#include <vector>
#include <fstream>

#ifdef MAC
#include <OpenCL/cl.h>
#else
#include <CL/cl.h>
#endif

using namespace std;

/* OpenCL structures */
	cl_device_id device;
	cl_context context;
	cl_program program;
	cl_kernel vector_kernel, complete_kernel, manhattan_distance_kernel;
	cl_kernel min_distance_kernel, update_weight_kernel;
	cl_command_queue queue;
	cl_event start_event, end_event;
	cl_int i, err;
	size_t local_size, global_size, net_size_cl;
	size_t chouxifu = 16;


	// claim parameters
	cl_int row, col, weight_ind;
	cl_int const train_sample_num = 1000;
	cl_int const net_size = 4;  //only const can be used in array define.
	cl_int const weight_size = 2;
	cl_int class_list[2] = {0, 1};
	cl_int top_feature_inds[2] = {0, 1};
	
	float weights[net_size][net_size][weight_size];
	float inputs[train_sample_num][weight_size];


	/* data_test and buffers */
	float data_test[ARRAY_SIZE];
	float sum, actual_sum;
	cl_mem data_buffer, sum_buffer;
	cl_mem weight_buffer, input_buffer;
	cl_mem distance_buffer, diff_buffer;
	cl_mem winner_dis_buffer;
	cl_mem winner_ind_buffer;
	cl_ulong time_start, time_end, total_time;


	int *winner_ind = (int*)malloc(sizeof(int)); 


/* Find a GPU or CPU associated with the first available platform */
cl_device_id create_device() {

	cl_platform_id platform;
	cl_device_id dev;
	int err;

	/* Identify a platform */
	err = clGetPlatformIDs(1, &platform, NULL);
	if (err < 0) {
		perror("Couldn't identify a platform");
		exit(1);
	}

	/* Access a device */
	err = clGetDeviceIDs(platform, CL_DEVICE_TYPE_GPU, 1, &dev, NULL);
	if (err == CL_DEVICE_NOT_FOUND) {
		err = clGetDeviceIDs(platform, CL_DEVICE_TYPE_CPU, 1, &dev, NULL);
	}
	if (err < 0) {
		perror("Couldn't access any devices");
		exit(1);
	}

	return dev;
}

/* Create program from a file and compile it */
cl_program build_program(cl_context ctx, cl_device_id dev, const char* filename) {

	cl_program program;
	FILE *program_handle;
	char *program_buffer, *program_log;
	size_t program_size, log_size;
	int err;

	/* Read program file and place content into buffer */
	program_handle = fopen(filename, "r");
	if (program_handle == NULL) {
		perror("Couldn't find the program file");
		exit(1);
	}


	fseek(program_handle, 0, SEEK_END);
	program_size = ftell(program_handle);
	rewind(program_handle);
	program_buffer = (char*)malloc(program_size + 1);
	program_buffer[program_size] = '\0';
	fread(program_buffer, sizeof(char), program_size, program_handle);
	fclose(program_handle);

	/* Create program from file */
	program = clCreateProgramWithSource(ctx, 1,
		(const char**)&program_buffer, &program_size, &err);
	if (err < 0) {
		perror("Couldn't create the program");
		exit(1);
	}
	free(program_buffer);

	/* Build program */
	err = clBuildProgram(program, 0, NULL, NULL, NULL, NULL);
	if (err < 0) {

		/* Find size of log and print to std output */
		clGetProgramBuildInfo(program, dev, CL_PROGRAM_BUILD_LOG,
			0, NULL, &log_size);
		program_log = (char*)malloc(log_size + 1);
		program_log[log_size] = '\0';
		clGetProgramBuildInfo(program, dev, CL_PROGRAM_BUILD_LOG,
			log_size + 1, program_log, NULL);
		printf("%s\n", program_log);
		free(program_log);
		exit(1);
	}

	return program;
}


// find winner function
void find_winner(int input_index){

	// Assign the index representing the start of the current input vector to the distance kernel
	err = clSetKernelArg(manhattan_distance_kernel, 5, sizeof(int), &input_index);
	if (err < 0) {
		perror("Couldn't create a kernel argument for manhattan_distance_kernel");
		exit(1);
	}


	// Enqueue kernel with as many work items as there are neurons in the map
	err = clEnqueueNDRangeKernel(queue, manhattan_distance_kernel, 1, NULL, &chouxifu, NULL, 0, NULL, NULL);
	if (err < 0) {
		perror("Couldn't enqueue the manhattan_distance_kernel");
		cout<< err;
		exit(1);
	}

	//enqueue is non-blocking, so we need wait using clfinish to make sure this queue is finished before proceeding.
	clFinish(queue);



	// Enqueue min_distance kernel so that each work item deals with more than one neuron
	err = clEnqueueNDRangeKernel(queue, min_distance_kernel, 1, NULL, &chouxifu, NULL, 0, NULL, NULL);
	if (err < 0) {
		perror("Couldn't enqueue the min_distance_kernel");
		cout<< err;
		exit(1);
	}

// wait


	clFinish(queue);
	/* Read the result */

	float *distance = (float*)malloc(sizeof(float)*16);
	err = clEnqueueReadBuffer(queue, distance_buffer, CL_TRUE, 0,
		16 * sizeof(float), distance, 0, NULL, NULL);
	if (err < 0) {
		perror("Couldn't read the distance_buffer");
		exit(1);
	}

	for(int i = 0; i<16; i++){
		cout << "distance[" << i << "] = " << distance[i] << "\n";
	}

	float *diff = (float*)malloc(sizeof(float)*16);
	err = clEnqueueReadBuffer(queue, diff_buffer, CL_TRUE, 0,
		16 * sizeof(float), diff, 0, NULL, NULL);
	if (err < 0) {
		perror("Couldn't read the diff_buffer");
		exit(1);
	}

	for(int i = 0; i<16; i++){
		cout << "diff[" << i << "] = " << diff[i] << "\n";
	}




	float *winner_dis = (float*)malloc(sizeof(float)); 
	err = clEnqueueReadBuffer(queue, winner_dis_buffer, CL_TRUE, 0, sizeof(float), winner_dis, 0, NULL, NULL);
	if (err < 0) {
		perror("Couldn't read the winner_dis_buffer");
		exit(1);
	}

	cout << "winner_dis" << *winner_dis << "\n";


	int *winner_ind = (int*)malloc(sizeof(int)); 
	err = clEnqueueReadBuffer(queue, winner_ind_buffer, CL_TRUE, 0, sizeof(int), winner_ind, 0, NULL, NULL);
	if (err < 0) {
		perror("Couldn't read the winner_ind_buffer");
		exit(1);
	}

	cout << "winner_ind" << *winner_ind << "\n";

}


/*
	Function that changes the weights of the map according to their position relative to the winning point and the input vector.
*/
void update_weights(int input_start_index, int vector_size){
	// int current_pos, neighbourhood_value;
	// int map_size = map_side_size*map_side_size*vector_size;

	// Set the start index for the current vector for the update_weight kernel.

	err = clSetKernelArg(update_weight_kernel, 6, sizeof(int), &input_start_index);
	if (err < 0) {
		perror("Couldn't create a kernel argument for update_weight_kernel");
		exit(1);
	}

	
	// Enqueue the kernel with as many work units are there are neurons in the map
	err = clEnqueueNDRangeKernel(queue, update_weight_kernel, 1, NULL, &chouxifu, NULL, 0, NULL, NULL);
	if (err < 0) {
		perror("Couldn't enqueue the update_weight_kernel");
		cout<< err;
		exit(1);
	}



	// Wait for completion
	clFinish(queue);

	// read result
	float *updated_weights = (float*)malloc(sizeof(float)*32);
	err = clEnqueueReadBuffer(queue, weight_buffer, CL_TRUE, 0,
		32 * sizeof(float), updated_weights, 0, NULL, NULL);
	if (err < 0) {
		perror("Couldn't read the weight_buffer");
		exit(1);
	}
	for(int i = 0; i<32; i++){
		cout << "updated_weights[" << i << "] = " << updated_weights[i] << "\n";
	}
}


int main() {
	

	/* Initialize data_test */
	for (i = 0; i<ARRAY_SIZE; i++) {
		data_test[i] = 1.0f*i;
	}


	for (row = 0; row<net_size; row++){
		for (col = 0; col<net_size; col++){
			for (weight_ind = 0; weight_ind < weight_size; weight_ind++){
				weights[net_size][net_size][weight_size] = (rand() / double(RAND_MAX))*0.3 + 0.35;
			}
		}
	}


	// read input file
	ifstream in("input.csv");
	string line, field;
	vector< vector<string> > array;  // the 2D array
	vector<string> v;                // array of values for one line only

	while (getline(in, line))    // get next line in file
	{
		v.clear();
		stringstream ss(line);

		while (getline(ss, field, ','))  // break line into comma delimitted fields
		{
			v.push_back(field);  // add each field to the 1D array
		}

		array.push_back(v);  // add the 1D array to the 2D array
	}

	// print out what was read in


// string str;
// float f=atof(str.c_str());




	for (size_t i = 0; i<train_sample_num; ++i)
	{
		for (size_t k = 0; k<weight_size; ++k){
			//cout << array[i][top_feature_inds[k]] << "|"; // (separate fields by |)
			inputs[i][k] = atof(array[i][top_feature_inds[k]].c_str());
		}
		
		//cout << "\n";
	}




	/* Create device and determine local size */
	device = create_device();
	err = clGetDeviceInfo(device, CL_DEVICE_MAX_WORK_GROUP_SIZE,
		sizeof(local_size), &local_size, NULL);
	if (err < 0) {
		perror("Couldn't obtain device information");
		exit(1);
	}

	cout << "CL_DEVICE_MAX_WORK_GROUP_SIZE: " << CL_DEVICE_MAX_WORK_GROUP_SIZE << "\n";
	cout << "local size is :" <<local_size << "\n";

	/* Create a context */
	context = clCreateContext(NULL, 1, &device, NULL, NULL, &err);
	if (err < 0) {
		perror("Couldn't create a context");
		exit(1);
	}

	/* Build program */
	program = build_program(context, device, PROGRAM_FILE);

	/* Create data_test buffer */

	float inputs_1[2] = {1.01, 0.99};
	float weights_1[32] = {0.100, 	0.200, 	0.300, 	0.400, 	0.50,  0.60,  0.70,  0.80,  0.90,  1,	1.1,  1.2,  1.3,  1.4,  1.5,  1.6,  1.7,  1.8,  1.9,  2,	2.1,  2.2,  2.3,  2.4,  2.5,  2.6,  2.7,  2.8,  2.9,  3,	3.1,  3.2};
	// float distance[16] = {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};

	// for(int i = 0; i<16; i++){
	// 		cout << "distance[" << i << "] = " << distance[i] << "\n";
	// }


								data_buffer = clCreateBuffer(context, CL_MEM_READ_WRITE | CL_MEM_USE_HOST_PTR, ARRAY_SIZE * sizeof(float), data_test, &err);
								if (err < 0) {
									cout << "data_buffer = clCreateBuffer error" <<err << "\n";
									exit(1);
								}
	weight_buffer = clCreateBuffer(context, CL_MEM_READ_WRITE | CL_MEM_USE_HOST_PTR, 16*2 * sizeof(float), weights_1, &err);
	if (err < 0) {
		cout << "weight_buffer = clCreateBuffer error" <<err << "\n";
		exit(1);
	}
	

								sum_buffer = clCreateBuffer(context, CL_MEM_WRITE_ONLY, sizeof(float), NULL, &err);
								if (err < 0) {
									cout << "sum_buffer = clCreateBuffer error" <<err << "\n";
									exit(1);
								}

	input_buffer = clCreateBuffer(context, CL_MEM_READ_WRITE | CL_MEM_USE_HOST_PTR, 2 * sizeof(float), inputs_1, &err);
	if (err < 0) {
		cout << "input_buffer = clCreateBuffer error" <<err << "\n";
		exit(1);
	}

	distance_buffer = clCreateBuffer(context, CL_MEM_WRITE_ONLY, net_size*net_size*sizeof(float), NULL, &err);
	if (err < 0) {
		cout << "distance_buffer = clCreateBuffer error" <<err << "\n";
		exit(1);
	}

	diff_buffer = clCreateBuffer(context, CL_MEM_WRITE_ONLY, net_size*net_size*sizeof(float), NULL, &err);
	if (err < 0) {
		cout << "diff_buffer = clCreateBuffer error" <<err << "\n";
		exit(1);
	}



	/* Create a command queue */
	queue = clCreateCommandQueue(context, device, CL_QUEUE_PROFILING_ENABLE, &err);
	if (err < 0) {
		perror("Couldn't create a command queue");
		exit(1);
	};

	/* Create kernels */
								vector_kernel = clCreateKernel(program, KERNEL_1, &err);
								if (err < 0) {
									perror("Couldn't create a vector_kernel");
									exit(1);
								};
								complete_kernel = clCreateKernel(program, KERNEL_2, &err);
								if (err < 0) {
									perror("Couldn't create a complete_kernel");
									exit(1);
								};

	manhattan_distance_kernel = clCreateKernel(program, MANHATTAN_DIS_KERNEL, &err);
	if (err < 0) {
		perror("Couldn't create a manhattan_distance_kernel");
		exit(1);
	};

	








	int start_index_1 = 0;

	/* Set arguments for vector kernel */
								err = clSetKernelArg(vector_kernel, 0, sizeof(cl_mem), &data_buffer);
								err |= clSetKernelArg(vector_kernel, 1, local_size * 4 * sizeof(float), NULL);
								if (err < 0) {
									perror("Couldn't create a kernel argument for vector_kernel");
									exit(1);
								}

	/* Set arguments for complete kernel */
								err = clSetKernelArg(complete_kernel, 0, sizeof(cl_mem), &data_buffer);
								if (err < 0) {
									perror("Couldn't create a kernel argument 0 for complete_kernel");
									exit(1);
								}
								err |= clSetKernelArg(complete_kernel, 1, local_size * 4 * sizeof(float), NULL);
								if (err < 0) {
									perror("Couldn't create a kernel argument 1 for complete_kernel");
									exit(1);
								}
								err |= clSetKernelArg(complete_kernel, 2, sizeof(cl_mem), &sum_buffer);
								if (err < 0) {
									perror("Couldn't create a kernel argument 2 for complete_kernel");
									cout << err << "\n";
									exit(1);
								}

	/* Set arguments for manhattan_distance_kernel*/
	err = clSetKernelArg(manhattan_distance_kernel, 0, sizeof(cl_mem), &input_buffer);
	err |= clSetKernelArg(manhattan_distance_kernel, 1, sizeof(cl_mem), &weight_buffer);
	err |= clSetKernelArg(manhattan_distance_kernel, 2, sizeof(cl_mem), &distance_buffer);
	err |= clSetKernelArg(manhattan_distance_kernel, 3, sizeof(cl_mem), &diff_buffer);
	err |= clSetKernelArg(manhattan_distance_kernel, 4, sizeof(int), &weight_size);


	// err |= clSetKernelArg(manhattan_distance_kernel, 5, sizeof(int), &start_index_1);
	if (err < 0) {
		perror("Couldn't create a kernel argument for manhattan_distance_kernel");
		exit(1);
	}


	//create and set arguments for min_distance kernel.
	
	min_distance_kernel = clCreateKernel(program, MIN_DISTANCE_KERNEL, &err);
	if (err < 0) {
		perror("Couldn't create a manhattan_distance_kernel");
		exit(1);
	};



	winner_dis_buffer = clCreateBuffer(context, CL_MEM_WRITE_ONLY, sizeof(float), NULL, &err);
	if (err < 0) {
		cout << "sum_buffer = clCreateBuffer error" <<err << "\n";
		exit(1);
	}

	winner_ind_buffer = clCreateBuffer(context, CL_MEM_WRITE_ONLY, sizeof(float), NULL, &err);
	if (err < 0) {
		cout << "sum_buffer = clCreateBuffer error" <<err << "\n";
		exit(1);
	}

	err = clSetKernelArg(min_distance_kernel, 0, sizeof(cl_mem), &distance_buffer);
	err |= clSetKernelArg(min_distance_kernel, 1, local_size * sizeof(cl_mem), NULL);
	err |= clSetKernelArg(min_distance_kernel, 2, sizeof(cl_mem), &winner_dis_buffer);
	err |= clSetKernelArg(min_distance_kernel, 3, sizeof(cl_mem), NULL);
	err |= clSetKernelArg(min_distance_kernel, 4, sizeof(cl_mem), &winner_ind_buffer);


	if (err < 0) {
		perror("Couldn't create a kernel argument for min_distance_kernel");
		exit(1);
	}


	update_weight_kernel = clCreateKernel(program, UPFATE_WEIGHT_KERNEL, &err);
	if (err < 0) {
		perror("Couldn't create a update_weight_kernel");
		exit(1);
	};

	float neighbourhood_threshold = 2;
	float learning_rate = 0.01;


	err = clSetKernelArg(update_weight_kernel, 0, sizeof(cl_mem), &weight_buffer);
	err |= clSetKernelArg(update_weight_kernel, 1, sizeof(cl_mem), &input_buffer);
	err |= clSetKernelArg(update_weight_kernel, 2, sizeof(cl_mem), &diff_buffer);
	err |= clSetKernelArg(update_weight_kernel, 3, sizeof(float), &neighbourhood_threshold);
	err |= clSetKernelArg(update_weight_kernel, 4, sizeof(float), &learning_rate);
	err |= clSetKernelArg(update_weight_kernel, 5, sizeof(int), &winner_ind); 
	// err |= clSetKernelArg(update_weight_kernel, 6, sizeof(cl_mem), &winner_ind_buffer);
	err |= clSetKernelArg(update_weight_kernel, 7, sizeof(int), &weight_size);
	err |= clSetKernelArg(update_weight_kernel, 8, sizeof(int), &net_size);
	if (err < 0) {
		perror("Couldn't create a kernel argument for min_distance_kernel");
		exit(1);
	}








	find_winner(start_index_1);

	update_weights(start_index_1, weight_size);












	/* Enqueue kernels */
								global_size = ARRAY_SIZE / 4;
								err = clEnqueueNDRangeKernel(queue, vector_kernel, 1, NULL, &global_size, &local_size, 0, NULL, &start_event);
								if (err < 0) {
									perror("Couldn't enqueue the kernel");
									exit(1);
								}
								printf("Global size = %zu\n", global_size);








	/* Perform successive stages of the reduction */
								while (global_size / local_size > local_size) {
									global_size = global_size / local_size; 
									err = clEnqueueNDRangeKernel(queue, vector_kernel, 1, NULL, &global_size,
										&local_size, 0, NULL, NULL);
									printf("Global size = %zu\n", global_size);
									if (err < 0) {
										perror("Couldn't enqueue the kernel");
										exit(1);
									}
								}

								global_size = global_size / local_size;
								err = clEnqueueNDRangeKernel(queue, complete_kernel, 1, NULL, &global_size,
									NULL, 0, NULL, &end_event);
								if (err < 0) {
									perror("Couldn't enqueue the complete_kernel");
									cout<< err;
									exit(1);
								}
								printf("Global size = %zu\n", global_size);







	/* Finish processing the queue and get profiling information */
								clFinish(queue);
								clGetEventProfilingInfo(start_event, CL_PROFILING_COMMAND_START,
									sizeof(time_start), &time_start, NULL);
								clGetEventProfilingInfo(end_event, CL_PROFILING_COMMAND_END,
									sizeof(time_end), &time_end, NULL);
								total_time = time_end - time_start;



								err = clEnqueueReadBuffer(queue, sum_buffer, CL_TRUE, 0,
									sizeof(float), &sum, 0, NULL, NULL);
								if (err < 0) {
									perror("Couldn't read the sum_buffer");
									exit(1);
								}

	/* Check result */
								actual_sum = 1.0f * (ARRAY_SIZE / 2)*(ARRAY_SIZE - 1);
								if (fabs(sum - actual_sum) > 0.01*fabs(sum)){

									printf("Check failed.\n");
									cout <<"sum=" << sum << "\n";
									cout<< "sum_actual = " << actual_sum << "\n";
								}
								else
									printf("Check passed.\n");
								printf("Total time = %lu\n", total_time);

	/* Deallocate resources */
	clReleaseEvent(start_event);
	clReleaseEvent(end_event);
	clReleaseMemObject(sum_buffer);
	clReleaseMemObject(data_buffer);
	clReleaseKernel(vector_kernel);
	clReleaseKernel(complete_kernel);
	clReleaseCommandQueue(queue);
	clReleaseProgram(program);
	clReleaseContext(context);
	return 0;
}
